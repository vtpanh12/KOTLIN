package com.example.bestwishes.models

data class RequestRegisterOrLogin(
    val username: String
)
