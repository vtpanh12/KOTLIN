package com.example.bestwishes.models

data class UserResponse(
    val success: Boolean,
    val message: String,
    val idUser: String?
)
