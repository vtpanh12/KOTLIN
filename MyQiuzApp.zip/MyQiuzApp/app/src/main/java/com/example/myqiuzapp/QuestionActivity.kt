package com.example.myqiuzapp

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import com.example.myqiuzapp.databinding.ActivityMainBinding
import com.example.myqiuzapp.databinding.ActivityQuestionBinding

class QuestionActivity : AppCompatActivity() {
    private var mCurrentPosition: Int = 1
    private var mQuestionList: ArrayList<Question>? = null
    private var mSelectedOptionPosition: Int = 0
    private var mCorrectAnswer: Int = 0
    private var mUsername: String? = null

    lateinit var binding: ActivityQuestionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuestionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mUsername = intent.getStringExtra(Constants.USER_NAME)
        mQuestionList = Constants.getQuestions()
        binding.progressBar.max = mQuestionList?.size!!
        mCorrectAnswer = 0
        mSelectedOptionPosition = 0
        setQuestion()
        defaultOptionView()
        binding.tvOptionOne.setOnClickListener{setSelectedAnswer(binding.tvOptionOne, 1)
        Log.d("crash", "logapp")
        }
        binding.tvOptionTwo.setOnClickListener{setSelectedAnswer(binding.tvOptionTwo, 2)}
        binding.tvOptionThree.setOnClickListener{setSelectedAnswer(binding.tvOptionThree, 3)}
        binding.tvOptionFour.setOnClickListener{setSelectedAnswer(binding.tvOptionFour, 4)}

        binding.btnSubmit.setOnClickListener { onSubmit() }

    }



    private fun setSelectedAnswer(view: TextView, selectedIndex: Int) {
        defaultOptionView()
        mSelectedOptionPosition = selectedIndex
        view.setTextColor(Color.parseColor("#363a43"))
        view.setTypeface(view.typeface, Typeface.BOLD)
        view.setBackgroundResource(R.drawable.selected_option_boder_bg)
    }
    fun answerView(selected: Int, drawable: Int){
        when(selected){
            1 -> {binding.tvOptionOne.setBackgroundResource(drawable)}
            2 -> {binding.tvOptionTwo.setBackgroundResource(drawable)}
            3 -> {binding.tvOptionThree.setBackgroundResource(drawable)}
            4 -> {binding.tvOptionFour.setBackgroundResource(drawable)}
        }
    }

    private fun onSubmit() {
        if(mSelectedOptionPosition == 0){
            mCurrentPosition++
            when{
                mCurrentPosition <= mQuestionList!!.size -> {
                    setQuestion()
                }
                else -> {
                    val intent = Intent(this, ResultActivity::class.java)
                    intent.putExtra(Constants.USER_NAME, mUsername)
                    intent.putExtra(Constants.CORRECT_ANSWER, mCorrectAnswer)
                    intent.putExtra(Constants.TOTAL_QUESTIONS, mQuestionList!!.size)
                    startActivity(intent)
                    finish()
                }
            }
        }
        else{
            val question = mQuestionList?.get(mCurrentPosition -1)
            if (question!!.correctAnswer != mSelectedOptionPosition){
                answerView(mSelectedOptionPosition, R.drawable.wrong_option_boder_bg)
            }
            else{
                mCorrectAnswer +=1
            }
            answerView(question!!.correctAnswer, R.drawable.correct_option_boder_bg)
            if (mCurrentPosition == mQuestionList!!.size){
                binding.btnSubmit.text = "FINISH"
            }
            else{
                binding.btnSubmit.text =" GO TO THE NEXT QUESTION"
            }
            mSelectedOptionPosition = 0
        }
    }
    private fun defaultOptionView() {
        val options = ArrayList<TextView>()
        options.add(binding.tvOptionOne)
        options.add(binding.tvOptionTwo)
        options.add(binding.tvOptionThree)
        options.add((binding.tvOptionFour))
        for (option in options){
            option.typeface = Typeface.DEFAULT
            option.setBackgroundResource(R.drawable.default_option_boder_bg)
            option.setTextColor(Color.parseColor("#7a8089"))
        }
    }

    private fun setQuestion() {
        defaultOptionView()
        val question: Question = mQuestionList!![mCurrentPosition - 1]

        binding.progressBar.progress = mCurrentPosition
        binding.tvProgress.text = "$mCurrentPosition/${binding.progressBar.max}"

        binding.tvQuestion.text = question.question
        binding.tvOptionOne.text = question.optionOne
        binding.tvOptionTwo.text = question.optionTwo
        binding.tvOptionThree.text = question.optionThree
        binding.tvOptionFour.text = question.optionFour

        binding.tvImage.setImageResource(question.image)

        if(mCurrentPosition == mQuestionList!!.size){
            binding.btnSubmit.text = "FINISH"
        }
        else{
            binding.btnSubmit.text = "SUBMIT"
        }
    }
}