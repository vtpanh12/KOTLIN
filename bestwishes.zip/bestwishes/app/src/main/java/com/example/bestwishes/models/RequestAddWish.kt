package com.example.bestwishes.models

import com.google.gson.annotations.SerializedName

data class RequestAddWish(
    val idUser: String,
    //annotation SerializedName dùng để đối đúng tên tham số truyền lên Server
    @SerializedName("name")
    val fullname: String,
    val content: String
)
