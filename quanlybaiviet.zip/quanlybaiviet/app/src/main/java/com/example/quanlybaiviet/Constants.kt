package com.example.quanlybaiviet
// tạo 1 đối tượng constants, có cái biến là các hằng số
object Constants {
    const val NEWS_TABLE="news_table"
    const val NEWS_DATABASE="news_database"
    const val BUNDLE_NEWS_ID="bundle_news_id"
}