package com.example.quanlybaiviet

import androidx.room.Database
import androidx.room.RoomDatabase
//Tạo database, chỉ định NewsEntiny là lớp duy nhất chứa danh sách entities
@Database(entities = [NewsEntity::class], version = 1)
//Lớp trừu tượng NewsDatabase là lớp mở rộng của RoomDatabase
abstract class NewsDatabase : RoomDatabase() {
    abstract fun doa():NewsDao
    //lớp doa() trả về là 1 đối tượng của lớp NewsDao đã khai báo
}
