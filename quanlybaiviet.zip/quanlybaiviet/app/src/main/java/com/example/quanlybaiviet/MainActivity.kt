package com.example.quanlybaiviet

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import com.example.quanlybaiviet.Constants.NEWS_DATABASE
import com.example.quanlybaiviet.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.btnAddNews.setOnClickListener {
            var intent = Intent(this, AddNewsActivity::class.java)
            startActivity(intent)
        }
    }
    private val newsDB : NewsDatabase by lazy { //biến đó có thể được gọi nhiều lần, nhưng chỉ khởi tạo 1 lần duy nhất vào lần truy cập đầu tiên
        //dataBuilder: trình tạo cơ sở dữ liệu để tải dữ liệu
        Room.databaseBuilder(this, NewsDatabase::class.java, NEWS_DATABASE)
            .allowMainThreadQueries()
            .fallbackToDestructiveMigration()
            //Tạo phiên bản thể hiện của cơ sở dữ liệu, sẽ xóa các lỗi trên Android Studio, xóa csdl
            .build()
    }
    private val newsAdapter by lazy { NewsAdapter() }
    override fun onResume() {
        //super: gọi từ lớp cha
        super.onResume()
        checkItem()
    }
    //kiểm tra xen ds có rỗng hay không, để hiển thị
    private fun checkItem() {
        binding.apply {
            if(newsDB.doa().getAllNews().isNotEmpty()){
                rvNewsList.visibility = View.VISIBLE    //nếu không rỗng hiện danh sách đã thêm vào
                tvEmptyText.visibility = View.GONE      //ẩn đoạn text chưa có bài viết
                newsAdapter.differ.submitList((newsDB.doa().getAllNews())) //cập nhật dữ liệu submitList()
                setupRecyclerView() //set recyclerview
            }
            else{
                rvNewsList.visibility = View.GONE
                tvEmptyText.visibility = View.VISIBLE
            }
        }
    }

    private fun setupRecyclerView() {
        binding.rvNewsList.apply {
            layoutManager = LinearLayoutManager(this@MainActivity) //hiển thị ds theo linear vertical: thẳng
            adapter = newsAdapter //adapter của RCV = newsAdapter cập nhật mỗi khi có thay đổi vào rvNewsList
        }
    }
}