package com.example.quanlybaiviet

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.quanlybaiviet.Constants.NEWS_TABLE
//Tạo class data cho bài viết
@Entity(tableName = NEWS_TABLE)
//đánh dấu là một lớp thực thể cơ sở dữ liệu, với bảng cơ sở dữ liệu tên là NEWS_TABLE (bảng SQLite)
data class NewsEntity(
    @PrimaryKey(autoGenerate = true)  //autoGenerate = true: tạo giá trị nhận dạng cho thực thể, id tự tăng, đảm bảo nó là giá trị duy nhất
    val newsID: Int,
    //khóa chính
    @ColumnInfo(name = "news_title") //tùy chỉnh cột liên kết với một trường cụ thể name = "news_title: định tên cho cột
    val newsTitle: String,
    @ColumnInfo(name = "news_desc") //đặt tên cho cột
    val newsDesc: String    //biến để lưu thông tin
)
