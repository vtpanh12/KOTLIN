package com.example.bestwishes.models

data class RequestDeleteWish(
    val idUser: String,
    val idWish: String
)
