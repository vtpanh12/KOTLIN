package com.example.bestwishes.models

data class ResponseMessage(
    val success: Boolean,
    val message: String
)
