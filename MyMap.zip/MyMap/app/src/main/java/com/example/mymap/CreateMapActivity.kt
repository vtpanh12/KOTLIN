package com.example.mymap

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.Toast
import androidx.core.content.ContextCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.mymap.databinding.ActivityCreateMapBinding
import com.google.android.gms.maps.model.Marker
import com.google.android.material.snackbar.Snackbar
import models.Place
import models.UserMap

class CreateMapActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private var markers: MutableList<Marker> = mutableListOf<Marker>()
    private lateinit var binding: ActivityCreateMapBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCreateMapBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val title = intent.getStringExtra(Utils.EXTRA_MAP_TITLE)
        supportActionBar?.title = title

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        mapFragment.view?.let {
            Snackbar.make(
                it, "Long press to add a marker!",
                Snackbar.LENGTH_INDEFINITE
            )
                .setAction("OK", {})
                .setActionTextColor(ContextCompat.getColor(this, R.color.white))
                .show()

        }
    }
    //tạo menu
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_create_map, menu)
        return super.onCreateOptionsMenu(menu)
    }
    //xử lý sự kiện khi click vào menu
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.miSave){
            Log.i("tag", "Clicked on Save!")
            if (markers.isEmpty()){
                Toast.makeText(this, "There must be at least one marker on the map", Toast.LENGTH_SHORT).show()
                    return true
            }
            val places = markers.map{
                    it -> Place(it.title!!, it.snippet!!, it.position.latitude,
                it.position.longitude)
            }
            val userMap =
                UserMap(intent.getStringExtra(Utils.EXTRA_MAP_TITLE)!!, places)
            val data = Intent()
            data.putExtra(Utils.EXTRA_USER_MAP, userMap)
            //set kq trả về cho activity main
            setResult(Activity.RESULT_OK, data)
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    //xử lú sự kiện khi load bản đồ thành công
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        //hiện thông tin của marker
        mMap.setOnInfoWindowClickListener { marker ->
            Log.i("tag","setOnInfoWindowClickListener - Delete")
            //khi bấm vào có thể xóa marker
            markers.remove(marker)
            marker.remove()
        }
        //latLng: biến tham chiếu tới kinh độ và vĩ độ
        mMap.setOnMapLongClickListener { latLng ->
            Log.i("tag","setOnMapLongClickListener")
            val placeFormView = LayoutInflater.from(this).inflate(R.layout.diaglog_create_place, null)
            AlertDialog.Builder(this).setTitle("Create a marker")
                .setView(placeFormView)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("OK"){ _,_ ->
                    //nhập vào title và desc
                    val _title = placeFormView.findViewById<EditText>(R.id.et_title).text.toString()
                    val _description = placeFormView.findViewById<EditText>(R.id.et_description).text.toString()
                    //kiểm tra rỗng
                    if (_title.trim().isEmpty() || _description.trim().isEmpty()){
                        Toast.makeText(this, "Fill out title & description", Toast.LENGTH_SHORT).show()
                        return@setPositiveButton
                    }
                    //addMarker: thêm 1 marker vào bản đồ (tọa độ, tiêu đề, nội dung)
                    val marker = mMap.addMarker(MarkerOptions().position(latLng).title(_title).snippet(_description)
                    )
                    //danh sách lưu những địa điểm
                    markers.add(marker!!)
                }
                .show()
        }
        // Add a marker in CTU and move the camera
        //địa điểm mặc định
        val ctu = LatLng(10.031452976258134, 105.77197889530333)
        mMap.addMarker(MarkerOptions().position(ctu).title("Trường ĐH Cần Thơ"))
        //moveCamera: zoom lên 10f (cấp 10)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(ctu, 10f))

    }
}