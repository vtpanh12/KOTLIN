package com.example.bestwishes.fragment

import android.os.Bundle
import android.provider.SyncStateContract
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.PixelCopy.Request
import com.example.bestwishes.apis.Constants
import android.view.View
import android.view.ViewGroup
import com.example.bestwishes.R
import com.example.bestwishes.databinding.FragmentRegisterBinding
import com.example.bestwishes.models.RequestRegisterOrLogin
import com.example.bestwishes.sharedpreferences.AppSharedPreferences
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

import java.util.prefs.AbstractPreferences

class RegisterFragment : Fragment() {
    private lateinit var binding: FragmentRegisterBinding
    private lateinit var mAppSharedPreferences: AppSharedPreferences
    private var username = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentRegisterBinding.inflate(layoutInflater, container, false)
        //Khoi tao mAppSharedPreferences
        mAppSharedPreferences = AppSharedPreferences(requireContext())

        binding.apply {
            btnRegister.setOnClickListener {
                if (edtUsername.text.isNotEmpty()){
                    username =  edtUsername.text.toString().trim()
                    //Thuc hien call api dang ky tai khoan
                    registerUser(username)
                }
                else{
                    Snackbar.make(it, "Vui long nhap ma so sinh vien!", Snackbar.LENGTH_LONG).show()
                }
            }
            tvLogin.setOnClickListener {
                requireActivity().supportFragmentManager.beginTransaction()
                    .replace(R.id.frame_layout, LoginFragment())
                    .commit()
            }
        }
        // Inflate the layout for this fragment
        return binding.root
    }

    private fun registerUser(username: String) {
        binding.apply {
            progressBar.visibility = View.VISIBLE
            CoroutineScope(Dispatchers.IO).launch {
                withContext(Dispatchers.Main){
                    val response = Constants.getInstance().loginUser(
                        RequestRegisterOrLogin(username)
                    )
                        .body()
                    if (response != null){
                        if (response.success){
                            //Dang nhap tai khoan thanh cong
                            //Nhap idUser va thuc hien luu vao sharedPreferences
                            mAppSharedPreferences.putIdUser("idUser", response.idUser!!)
                            requireActivity().supportFragmentManager.beginTransaction()
                                .replace(R.id.frame_layout, WishListFragment())
                                .commit()
                            progressBar.visibility = View.GONE
                        }
                        else{
                            //Dang nhap tai khoan that bai
                            tvMessage.text = response.message
                            tvMessage.visibility = View.VISIBLE
                            progressBar.visibility = View.GONE
                        }
                    }
                }
            }
        }
    }
}