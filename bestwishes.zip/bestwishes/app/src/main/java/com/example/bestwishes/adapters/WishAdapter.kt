package com.example.bestwishes.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewParent
import androidx.recyclerview.widget.RecyclerView
import com.example.bestwishes.databinding.ActivityMainBinding
import com.example.bestwishes.databinding.ItemWishBinding
import com.example.bestwishes.models.Wish
import com.example.bestwishes.sharedpreferences.AppSharedPreferences
import java.lang.reflect.Type
import com.bumptech.glide.Glide
import com.example.bestwishes.R
import java.text.ParsePosition

class WishAdapter (
    private val context: Context,
    private val wishList: List<Wish>,
    private val appSharedPreferences: AppSharedPreferences,
    //Truyen interface tu ben ngoai vao
    private val iClickItemWish: IClickItemWish,
    ): RecyclerView.Adapter<WishAdapter.WishViewHolder>() {
    class WishViewHolder(val binding: ItemWishBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WishViewHolder {
        return WishViewHolder(
            ItemWishBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return wishList.size
    }

    override fun onBindViewHolder(holder: WishViewHolder, position: Int) {
        //Lay ra doi tuong wish o vi tri position va thiet lap len giao dien
        val wish: Wish = wishList[position]
        holder.binding.tvName.text = wish.content
        holder.binding.tvContent.text = wish.content
        Glide.with(context).load(wish.owner.avatar)
            .error(R.drawable.avt_default)
            .into(holder.binding.imgAvatar)

        //Neu nguoi dung dang dang nhap la chu nhan dieu uoc o vi tri position
        //thi hien thi icon update va delete
        if (appSharedPreferences.getIdUser("idUser").toString() == wish.owner._id) {
            holder.binding.imgUpdate.visibility = View.VISIBLE
            holder.binding.imgDelete.visibility = View.VISIBLE
        }

        //Bat ky su kien click vao bieu tuong xoa va cap nhap thi thuc hien ham tuong ung da khai bao trong interface
        holder.binding.imgDelete.setOnClickListener {
            iClickItemWish.onClickRemove(wish._id)
        }

        holder.binding.imgUpdate.setOnClickListener {
            iClickItemWish.onClickUpdate(wish._id, wish.name, wish.content)
        }
    }

    //Dinh nghia 1 interface chua cac ham khi thuc hien click tung item
    interface IClickItemWish {
        fun onClickUpdate(idWish: String, fullName: String, content: String)
        fun onClickRemove(idWish: String)
    }
}
