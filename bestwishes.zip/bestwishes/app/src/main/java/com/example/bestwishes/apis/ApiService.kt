package com.example.bestwishes.apis

import android.view.PixelCopy.Request
import com.example.bestwishes.models.RequestAddWish
import com.example.bestwishes.models.RequestDeleteWish
import com.example.bestwishes.models.RequestUpdateWish
import com.example.bestwishes.models.RequestRegisterOrLogin
import com.example.bestwishes.models.ResponseMessage
import com.example.bestwishes.models.UserResponse
import com.example.bestwishes.models.Wish
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.HTTP
import retrofit2.http.PATCH
import retrofit2.http.POST

class Constants{
    companion object{
        private const val  BASE_URL = "http://158.178.227.41:6868/api/"

        fun getInstance(): ApiService{
            return Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(BASE_URL)
                .build()
                .create(ApiService::class.java)
        }
    }
}
interface ApiService {
    @GET("wishes")
    suspend fun getWishList(): Response<List<Wish>>

    @POST("wishes")
    suspend fun addWish(
        @Body addWish: RequestAddWish
    ): Response<ResponseMessage>

    @PATCH("wishes")
    suspend fun updateWish(
        @Body updateWish: RequestUpdateWish
    ): Response<ResponseMessage>

    @HTTP(method = "DELETE", path = "wishes", hasBody = true)
    suspend fun deleteWish(
        @Body deleteWish: RequestDeleteWish
    ): Response<ResponseMessage>

    @POST("users/register")
    suspend fun registerUser(
        @Body request: RequestRegisterOrLogin
    ): Response<UserResponse>

    @POST("users/login")
    suspend fun loginUser(
        @Body request: RequestRegisterOrLogin
    ): Response<UserResponse>
}