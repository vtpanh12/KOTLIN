package com.example.quanlybaiviet

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.room.Room
import com.example.quanlybaiviet.Constants.BUNDLE_NEWS_ID
import com.example.quanlybaiviet.databinding.ActivityUpdateNewsBinding
import com.google.android.material.snackbar.Snackbar


class UpdateNewsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUpdateNewsBinding

    private lateinit var newsEntity: NewsEntity
    private var newsId = 0
    private var defaultTitle = ""
    private var defaultDesc = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityUpdateNewsBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        intent.extras?.let {
            //Bundle: key-value, có thể được đóng gói và truyền đi giữa các thành phần của ứng dụng
            //extras: truy cap vao 1 bundle
            //let{} chỉ thực thi lệnh khi nó không rỗng
            newsId = it.getInt(BUNDLE_NEWS_ID)
            //lấy dữ liệu Int từ BUNDLE_NEWS_ID gán cho newsId
        }

        binding.apply {
            defaultTitle = newsDB.doa().getNews(newsId).newsTitle
            //lấy title có query là getNews( id: newsID) gán cho defaultTitle
            defaultDesc = newsDB.doa().getNews(newsId).newsDesc

            edtTitle.setText(defaultTitle)
            //Sets the text to be displayed
            edtDesc.setText(defaultDesc)

            btnDelete.setOnClickListener {
                //khi click vào nút DELETE
                newsEntity = NewsEntity(newsId, defaultTitle, defaultDesc)
                //tạo 1 đối tượng từ có newsID, defaultTitle, defaultDesc
                newsDB.doa().deleteNews(newsEntity)
                //gọi hàm xóa deleNews, xóa newsEntity từ doa()
                finish()
            }
            btnSave.setOnClickListener {
                val title = edtTitle.text.toString()
                val desc = edtDesc.text.toString()
                if(title.isNotEmpty() || desc.isNotEmpty()){
                    newsEntity = NewsEntity(newsId, title, desc)
                    //UPDATE NEWS_TABLE SET news_title = $title, news_desc =  $desc WHERE newsId = newsId
                    newsDB.doa().updateNews(newsEntity)
                    finish()
                }
                else{
                    Snackbar.make(it, "Title and Description cannot be Empty", Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }
    private val newsDB : NewsDatabase by lazy {
        //dataBuiler: tạo 1 csdl
        Room.databaseBuilder(this, NewsDatabase::class.java, Constants.NEWS_DATABASE)
            .allowMainThreadQueries()
            .fallbackToDestructiveMigration()
            .build()
    }
}