package com.example.quanlybaiviet

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.quanlybaiviet.Constants.NEWS_TABLE
//Tạo đối tượng truy cập cho bài viết
@Dao
//DAO: Đối tượng truy cập dữ liệu, cung cấp một giao diện trừu tượng
//truy cập dữ liệu là các thành phần chính của Room, xác định giao diện truy cập vào csdl
interface NewsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertNews(newsEntity: NewsEntity)

    @Update
    fun updateNews(newsEntity: NewsEntity)

    @Delete
    fun deleteNews(newsEntity: NewsEntity)
    //order by: sap xep theo thu tu id
    //sắp xếp theo thứ tự từ lớn -> bé -> giảm dần (DESC), tăng dần (ASC)
    @Query("SELECT * FROM $NEWS_TABLE ORDER BY newsID DESC")
    fun getAllNews(): MutableList<NewsEntity>
    //chọn lọc ra các :id truyền vào tương đương với cột newsID
    @Query("SELECT * FROM $NEWS_TABLE WHERE newsID LIKE :id")
    fun getNews(id: Int) : NewsEntity
}