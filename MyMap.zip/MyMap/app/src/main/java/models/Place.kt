package models

import java.io.Serializable
//lưu địa điểm
data class Place(
    val title: String,
    val description: String,
    //kinh độ
    val latitude: Double,
    //vĩ độ
    val longitude: Double
):Serializable
