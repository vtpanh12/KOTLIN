package com.example.quanlybaiviet

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.room.Room
import com.example.quanlybaiviet.databinding.ActivityAddNewsBinding
import com.example.quanlybaiviet.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class AddNewsActivity : AppCompatActivity() {
    lateinit var binding: ActivityAddNewsBinding
    private lateinit var newsEntity: NewsEntity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddNewsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.apply {
           btnSave.setOnClickListener {
               val title = edTitle.text.toString() //lấy nội dung từ edTitle
               val desc = edtDesc.text.toString()
               if (title.isNotEmpty() || desc.isNotEmpty()){ //kiểm tra xem có rỗng không
                   newsEntity = NewsEntity(0, title, desc)
                   //tạo 1 đối tượng NewsEntity
                   newsDB.doa().insertNews(newsEntity)
                   //gọi newsDB của doa(),  thực hiện thêm 1 đối tượng là (newsEntity)
                   finish()
               }
               else{
                   Snackbar.make(it, "Title and Description cannot be Empty", Snackbar.LENGTH_LONG).show()
                   //hiện thông báo tương tư như Toast nhưng khác giao diện
               }
            }
        }
    }
    //lazy{}: được khởi tạo khi truy cập lần đầu tiên chứ không phải lúc run app
    private val newsDB : NewsDatabase by lazy {
        //xây dựng cơ sở dữ liệu của Room (this, lớp csdl của Room, tên của DB)
        Room.databaseBuilder(this, NewsDatabase::class.java, Constants.NEWS_DATABASE)
            //truy van du lieu tren luong chinh
            .allowMainThreadQueries()
            //nếu có lỗi sẽ xóa cdsl
            .fallbackToDestructiveMigration()
            //tạo lại
            .build()
    }
}