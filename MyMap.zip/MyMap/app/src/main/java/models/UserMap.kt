package models

import java.io.Serializable
//tạo được nhiều địa điểm
data class UserMap(
    //địa điểm
    val title: String,
    //danh sách địa điểm liên quan
    val places: List<Place>
):Serializable
