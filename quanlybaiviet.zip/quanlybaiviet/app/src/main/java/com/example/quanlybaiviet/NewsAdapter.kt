package com.example.quanlybaiviet

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.quanlybaiviet.Constants.BUNDLE_NEWS_ID
import com.example.quanlybaiviet.databinding.ActivityMainBinding
import com.example.quanlybaiviet.databinding.ItemNewsBinding
//Tạo Adapter cho bài viết, render dữ liệu qua RecyclerView
class NewsAdapter: RecyclerView.Adapter <NewsAdapter.ViewHolder>(){
    private lateinit var binding: ItemNewsBinding
    private lateinit var context: Context
    //tạo ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsAdapter.ViewHolder {
        var inflater = LayoutInflater.from(parent.context)
        binding = ItemNewsBinding.inflate(inflater, parent, false)
        //tạo ItemNewsBinding từ item_news.xml
        context = parent.context
        return ViewHolder()
    }
    //liên kết dữ liệu
    override fun onBindViewHolder(holder: NewsAdapter.ViewHolder, position: Int) {
        holder.bind(differ.currentList[position]) //hiện thị dữ liệu
        holder.setIsRecyclable(true) //có thể tái sử dụng
    }
    //số lượng Item
    override fun getItemCount(): Int {
        return differ.currentList.size
    }
    //inner class: nội bộ của class
    inner class ViewHolder : RecyclerView.ViewHolder(binding.root){
        @SuppressLint("SetTextI18n")
        fun bind(item: NewsEntity){ //bind: gán dữ liệu NewsEntity vào từng phần của Recyclerview
            //InitView
            binding.apply{//khi click chuột vào bất cứ đâu trên màn hình thì đều nhảy vào cập nhật
                //gán dữ liệu từ item ở trên vào tvTitle, tvDesc
                tvTitle.text = item.newsTitle
                tvDesc.text = item.newsDesc

                root.setOnClickListener{
                    //tạo 1 intent
                    val intent = Intent(context, UpdateNewsActivity::class.java)
                    //đưa dữ liệu qua (name, value)
                    intent.putExtra(BUNDLE_NEWS_ID, item.newsID)
                    context.startActivity(intent)
                }
            }
        }
    }
    //so sanh khac nhau
    private val differCallback = object : DiffUtil.ItemCallback<NewsEntity>(){
        //override lại areItemsTheSame: kiểm tra lại có cùng newsID ko
        override fun areItemsTheSame(oldItem: NewsEntity, newItem: NewsEntity): Boolean {
            return oldItem.newsID == newItem.newsID
        }
        //kiểm tra có cùng nội dung không
        override fun areContentsTheSame(oldItem: NewsEntity, newItem: NewsEntity): Boolean {
            return oldItem == newItem
        }
    }
    //AsyncListDiffer: công cụ trong Recyclerview -> sự khác biệt giữa 2 danh sách
    val differ = AsyncListDiffer(this, differCallback)
}